# Free Lead Magnet: The High-DPI AI Computer Use Checklist & Coordinate Cheatsheet
**By Best of Must Have — Tools for AI Agents**

---

## 1. Run Your Free Diagnostic First
Run `python diagnose_dpi_and_drag_physics.py` to measure your exact Windows scaling percentage (`125%`, `150%`, `200%`), multi-monitor pixel span, and `SM_CXDRAG` / `SM_CYDRAG` drag threshold.

---

## 2. The 4 Reasons AI Agents Fail Click-and-Drag on Windows 11
1. **Unscaled vs. Scaled Coordinates (`SetThreadDpiAwarenessContext -4`):**
   On a `2560x1440` monitor at `125%` scaling, a DPI-unaware tool sees `2048x1152` and misses the target by up to `512 px`.
2. **OS Drag Threshold (`SM_CXDRAG` = 4 px):**
   Jumping from `(X1, Y1)` to `(X2, Y2)` in one step never fires the initial small `WM_MOUSEMOVE` events while the button is held down, so Windows treats the action as a click.
3. **Tree-View & Folder Hover Delay (`600 ms` + `2 px` Wiggle):**
   File Explorer, Gmail dropzones, and desktop apps like Xactimate require the cursor to wiggle slightly and rest over the folder for `500–600 ms` before releasing the button.
4. **Synthetic Key Blocking (`LLKHF_INJECTED`) & Elevated Windows (`UIPI`):**
   Standard AutoHotkey hooks ignore synthetic `SendInput` events from AI agents unless paired with a `15 ms` Win32 `GetAsyncKeyState` poller and Administrator self-elevation (`Admin=1`).

---

## 3. Ready for the Complete 1-File Fix? (Use Code `FIRST25` for `$9` Early-Bird Pricing)
Get the **Universal AI Drag Bridge for All Apps** (`$19` regular — **`$9` for the first 25 buyers with code `FIRST25`**):
- **5 Universal Drag Modes:** Folder/Dropzone Drag (`Ctrl+Alt+Shift+2`), Box-Select Marquee Drag (`Ctrl+Alt+Shift+3`), Exact Slider/Chart Drag (`Ctrl+Alt+Shift+4`), Right-Click Drag (`Ctrl+Alt+Shift+5`), and Canvas Pan Drag (`Ctrl+Alt+Shift+6`).
- **Plug-and-Play MCP Server & HTTP REST API (`:7885`):** Works natively in Claude Desktop, Claude Code, Cursor, Windsurf, OpenAI Operator, and n8n.
- Or grab the **Complete 12-Tool "Tools for AI Agents" Pro Bundle (`$79`)** or the **6-Module Course + 120 Master SOPs (`$297`)**.
