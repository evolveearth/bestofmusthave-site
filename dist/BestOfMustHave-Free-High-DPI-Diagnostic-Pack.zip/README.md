---
uid: v-eech-master-readme-20261119
voice: studio-canonical
status: approved-reference
recorded: 2026-11-19
---

# EECH Master README & Agent-to-Agent Injection Handoff

> **EECH** = **EvolveEarth Coworker Harness** (also called the **EvolveEarth Computer-Use Harness**, AI PowerToy #18).
> **Canonical Scripts:**
> - Local Harness & Win32 / Virtual-Machine Driver: `C:\local-ai\studio_job_queue_and_tools\studio_tools\evolveearth_coworker_harness.py` (mirrored at `C:\local-ai\train-requests\_ops\evolveearth_computer_use_harness.py`)
> - Bi-Directional Desktop-to-Laptop Peer Agent Daemon (`:7891`): `C:\local-ai\studio_job_queue_and_tools\studio_tools\eech_peer_computer_use_agent.py`
> - Plain-English Agent Naming & Zero-Copy-Paste Handoff Bus: `C:\local-ai\studio_job_queue_and_tools\studio_tools\chat_goals.py`
> - Antigravity Lifecycle & `PreInvocation` Auto-Injector Hook: `C:\local-ai\studio_job_queue_and_tools\studio_tools\agy_hooks__lifecycle_to_studio.py`
> - Cross-Machine Prompt & Clipboard Bridge (`:7890`): `C:\local-ai\tools-for-ai-agents\18-cross-machine-ai-prompt-dispatcher\cross_machine_prompt_bridge.py`
> - Canonical Google Drive AutoHotkey Source: `%USERPROFILE%\My Drive\AutoHotkey\all-shortcuts.ahk`

---

## 1. Architecture & Live Port Map (How All Agents Connect to EECH)

EECH is the shared nervous system and motor harness across **Desktop AI Studio (`ALOHA` / `JESUS-911-WIKILEAKS`, Tailscale `100.113.12.85`, Root `C:\local-ai`)** and **Laptop Mobile Gaming (`LAPTOP-RAIDER`, Tailscale `100.94.239.19`, User `C:\Users\evolve`)**.

| Surface / Daemon | Live URL / Path | Role in Agent-to-Agent Prompting & EECH Injection |
|---|---|---|
| **EECH Primary JSON-RPC (JavaScript Object Notation Remote Procedure Call)** | `POST` [http://127.0.0.1:7863/api/harness](http://127.0.0.1:7863/api/harness) | Primary local injection endpoint for all 24 EECH verbs (`status`, `pass_chat`, `peer_prompt`, `employee_goal`, `ground`, `screenshot`, `key`, `type`, `click`, `drag`, `combo`, etc.). |
| **EECH Interactive Single-Screen Web App** | [http://127.0.0.1:7863/harness](http://127.0.0.1:7863/harness) · [http://127.0.0.1:8655/harness](http://127.0.0.1:8655/harness) · [http://127.0.0.1:7891/harness](http://127.0.0.1:7891/harness) | Visual human + browser-agent console for inspecting seats, screenshots, staged intents, and dispatching EECH commands. |
| **EECH Peer Computer-Use Agent Mesh (`:7891`)** | `POST` [http://127.0.0.1:7891/api/eech-peer/prompt](http://127.0.0.1:7891/api/eech-peer/prompt) · `POST` [http://127.0.0.1:8655/api/eech-peer](http://127.0.0.1:8655/api/eech-peer) | Real-time Desktop <-> Laptop agent-to-agent prompting over Tailscale (`100.113.12.85:7891` <-> `100.94.239.19:7891`) backed by `$0.00` warm local Ollama planning + deterministic skills. |
| **Google Drive Conflict-Free Peer Agent Bus** | `%USERPROFILE%\My Drive\Shared-Files-Laptop-Desktop-iPhone\EECH-Peer-Agent-Bus\{pending,completed,replies,screens}\` | Offline-resilient 3-second file-watcher bus so Desktop and Laptop agents can prompt each other even when one machine is asleep or off Tailscale. |
| **Antigravity `PreInvocation` Hook Auto-Injector** | `C:\local-ai\train-requests\_dash\feedback_chat_inbox.jsonl` -> `agy_hooks__lifecycle_to_studio.py` | Zero-copy-paste prompt injection straight into the next turn of Antigravity via `injectSteps` (`userMessage` + `[STUDIO HOOK PULSE]` `ephemeralMessage`). |
| **Cross-Machine IDE & Clipboard Dispatcher (`:7890`)** | `POST` [http://127.0.0.1:7890/](http://127.0.0.1:7890/) · `C:\local-ai\train-requests\_dash\remote_prompt_queue.json` | Mirrors full handoff prompts to `PROMPT-FOR-LAPTOP-ANTIGRAVITY.md`, Syncthing, Google Drive, OneDrive, Taildrop (`laptop-raider:`), and the Windows Clipboard. |
| **Bitwarden Login Valet Doorbell (`:7887`)** | `POST` [http://127.0.0.1:7887/api/mark-logged-in](http://127.0.0.1:7887/api/mark-logged-in) (`;bw5` / `;2fa` / `;door`) | Lets Joseph fill and submit credentials in 1 keystroke (`Ctrl+Alt+Shift+B`) and signal waiting browser/EECH agents to resume without any AI ever touching a password. |
| **Isolated Linux Agent Desktops (`:6081` / `:6082`)** | Docker `agent-desk-1` (`:6081`) & `agent-desk-2` (`:6082`) via `"vm": "agent-desk-1"` | Routes EECH GUI actions into isolated virtual desktops so host mouse/keyboard focus on Joseph's `3440x1440` screen is never disturbed. |
| **Machine-Readable LLM Discovery Manifest** | [http://127.0.0.1:7891/llms.txt](http://127.0.0.1:7891/llms.txt) · `C:\local-ai\desk\llms.txt` | Instant compact spec any local or remote agent can `GET` on Turn 1 to learn EECH endpoints, verbs, and safety gates. |

---

## 2. Mandatory Agent Naming & 2-Agent Handoff Laws (`2026-11-19` Law)

Before any agent prompts another agent or injects a handoff into EECH, obey these three hard rules enforced in code by `chat_goals.py` and `evolveearth_coworker_harness.py`:

1. **Plain-English Human-Readable Agent Names ONLY (`<Source Role in Surface> calling / prompting <Target Agent> for <Plain-English Goal>`):**
   - Every agent registration, progress row, and handoff MUST read as a clear plain-English sentence:
     - `Local File Server in Antigravity prompting Chrome-based agent for Altering the evolution of the Earth`
     - `Closing Claims Chat in Antigravity prompting Antigravity or Claude Code agent for Closing Claims — audit draft GLR and Xactimate sketch`
     - `Master Toolset Picker in Chrome calling Studio Toolset Gate for Closing Claims (improve Pil Layout + Hermes3:8b)`
   - **Permanently Banned:** Generic names (`Agent 1`, `Agent 2`, `worker1`, `default`), snake_case hash slugs (`orig_agy_desktop_6173c76c.goal_...`), and retired cartoon/fantasy callsigns (`Blueprint Rex`, `VaultKeeper Spine`, etc.). `chat_goals.build_human_agent_name()` rejects generic names with `ValueError` and automatically upgrades legacy slugs into plain English.
2. **Hard Cap on Handoffs — 1 or AT MOST 2 Agents, NEVER 3 (`PASS CHAT` Law):**
   - When passing work (`;prom3`..`;prom3333` or EECH `pass_chat`), pick **1 agent** (finish here if possible!) or split across **AT MOST 2 non-overlapping agents** (for example: **1** `Antigravity or Claude Code agent` for local code/files + **1** `Chrome-based agent` for authenticated browser portals/Testnet visual QA).
   - Passing `3` or more agents in `pass_chat` raises `ValueError: PASS CHAT LAW: Must pass to 1 or AT MOST 2 agents (NEVER 3)`.
3. **Disjoint File & Surface Locks (`locked_scope`):**
   - Code/file agents NEVER open browser tabs or hijack mouse/screen GUI (`Claude in Chrome` / GUI clicks stay off); browser QA agents NEVER edit local repo files or run `git`/`wrangler` commands.

---

## 3. All 5 Ways Agents Prompt Each Other & Inject Into EECH

### Method A — Direct EECH JSON-RPC Injection (`POST /api/harness` or Python `eech.dispatch`)

Any agent (Claude Code, Antigravity, n8n `:5678`, Hermes, or local Python) can inject structured actions into EECH over HTTP (`:7863`, `:8655`, or `:7891`) or by importing `evolveearth_coworker_harness` directly.

#### 1) Via Python (Recommended on Host — Zero Shell Quoting Issues)
```python
import sys
sys.path.insert(0, r"C:\local-ai\studio_job_queue_and_tools\studio_tools")
import evolveearth_coworker_harness as eech

# 1. Inspect live screen, cursor, active window, 14 business teams & staged queue
status = eech.dispatch({"verb": "status"})

# 2. Capture Per-Monitor DPI v2 screenshot + System-1 Jev visual grounding
ground = eech.dispatch({
    "verb": "ground",
    "prompt": "Verify Master Picker #testnet approval buttons are visible"
})

# 3. Dispatch prepare-only role work to one of the 182 Business Employee Seats
seat_res = eech.dispatch({
    "verb": "employee_goal",
    "pill": "closingclaims.claims-qa",
    "goal": "goal.closingclaims.06 · Audit draft GLR and Xactimate sketch"
})
```

#### 2) Via HTTP `POST http://127.0.0.1:7863/api/harness` (Works from Any Language, Container, or n8n HTTP Request Node)
```python
import json, urllib.request

def inject_eech(payload: dict) -> dict:
    req = urllib.request.Request(
        "http://127.0.0.1:7863/api/harness",  # Also served on :8655/api/harness and :7891/api/harness
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))

# Example: Run guarded multi-step combo ONLY if Notepad is foreground, aborting if Joseph moves mouse >50px
res = inject_eech({
    "verb": "combo",
    "expect_window": "Notepad",
    "yield_to_human": True,
    "steps": [
        {"verb": "type", "text": "Prepared scope summary ready for review."},
        {"verb": "key", "keys": "ctrl+s"}
    ],
    "assert_after": {"window_contains": "Notepad"}
})
```

#### 3) Complete EECH Verb Reference (`POST /api/harness`)
| Category | `verb` | Required / Key Fields | What EECH Executes |
|---|---|---|---|
| **State & Vision** | `status` | *(none)* | Returns screen rect (`5120x1440` multi-monitor aware), cursor `[x, y]`, foreground window, 14 businesses, 182 seats, and staged intent count. |
| **State & Vision** | `screenshot` (`snap`) | `"tag": "check"` | Captures sub-200ms Per-Monitor DPI PNG into `C:\local-ai\train-requests\_dash\computer_use_screens\` and updates `latest_desktop.png`. |
| **State & Vision** | `ground` | `"prompt": "..."` | Runs `JevDecisionEngine` System-1 grounding over a fresh screenshot without paid cloud calls. |
| **Agent Handoff** | `pass_chat` (`relay_chat`) | `"agents": [ ... ]` *(1 or max 2)* | Issues plain-English agent names via `chat_goals.py` and auto-delivers to `feedback_chat_inbox.jsonl` (`PreInvocation` hook), PowerToy #18 (`:7890`), Clipboard, and debug ledger. |
| **Peer Mesh** | `peer_prompt` (`peer_send`) | `"target": "laptop" \| "desktop" \| "both"`, `"prompt": "..."`, `"max_turns": 2` | Prompts the peer computer's local EECH Computer-Use Agent over `:7891` HTTP + Google Drive `EECH-Peer-Agent-Bus`. |
| **Peer Mesh** | `peer_status` / `peer_poll` | *(none)* | Returns Desktop <-> Laptop `:7891` reachability, beacons, pending envelopes, and replies (or polls Google Drive bus immediately). |
| **AHK Sync** | `setup_gdrive_ahk` | `"target": "both"` | Ensures `%USERPROFILE%\My Drive\AutoHotkey\all-shortcuts.ahk` startup + Scheduled Task on Desktop and Laptop, archiving stray Desktop `.ahk` files. |
| **Business OS** | `employee_goal` (`smart`) | `"pill": "<business>.<role>"`, `"goal": "..."` | Dispatches prepare-only desk work to a named business seat, logging to `Team/Memory/<role>.md` and `goal_agents_progress.jsonl`. |
| **PowerToys** | `powertoys` / `powertoy_run` | `"id": 1..18`, `"params": {...}` | Lists or runs any of the 18 AI PowerToys (`C:\local-ai\tools-for-ai-agents\`). |
| **Desktop Input** | `key` / `type` / `paste` | `"keys": "ctrl+s"` or `"text": "..."` | Sends Unicode UTF-16 `SendInput` or OEM-accurate virtual keys (`'.'` = `0xBE`, never `VK_DELETE`) after scanning text & clipboard for secrets. |
| **Desktop Input** | `click` / `drag` / `move` / `scroll` | `"x": 640, "y": 420` (or `"x1","y1","x2","y2"`) | Executes DPI-accurate cursor actions (`"vm": "agent-desk-1"` routes into isolated `:6081`/`:6082` Linux container desktop instead of host). |
| **Desktop Input** | `open` / `wait` / `combo` | `"app": "notepad"` / `"steps": [...]` | Launches allowlisted apps, waits up to 30s, or runs pre-scanned multi-step combos with before/after `visual_diff_pct` and `50px` human mouse yield. |

---

### Method B — Zero-Copy-Paste Agent-to-Agent Handoff & Antigravity Hook Injection (`pass_chat` -> `PreInvocation`)

When an agent in Antigravity or Claude Code needs to hand off or spawn follow-up work for **1 or at most 2 agents** without asking Joseph to copy-paste blocks manually:

```python
import sys
sys.path.insert(0, r"C:\local-ai\studio_job_queue_and_tools\studio_tools")
import evolveearth_coworker_harness as eech

result = eech.dispatch({
    "verb": "pass_chat",
    "agents": [
        {
            "business": "Closing Claims",
            "origination_chat": "Closing Claims Chat in Antigravity",
            "goal": "Audit carrier supplement macros and stage Testnet verification",
            "target_surface": "Antigravity or Claude Code agent",
            "target_machine": "desktop",
            "locked_scope": [
                r"C:\local-ai\projects\c01-root",
                r"C:\local-ai\studio_job_queue_and_tools\studio_tools"
            ],
            "prompt": (
                "DONE & VERIFIED:\n"
                "- Supplement macros staged in C:\\local-ai\\projects\\c01-root\\\n\n"
                "LOCKED SCOPE (Local Code & Selftests ONLY — Zero Browser Tabs):\n"
                "1. Run --selftest on all touched scripts.\n"
                "2. Stage card into BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet.\n\n"
                "MY ACTIVE CHECKLIST:\n"
                "[ ] Vote YAY or NAY + Feedback on #testnet"
            ),
            "auto_inject_hook": True,
            "auto_clipboard": True,
        },
        {
            "business": "Master Toolset Picker",
            "origination_chat": "Closing Claims Chat in Antigravity",
            "goal": "Verify 390x844 mobile zero-scroll and Testnet card buttons in Chrome",
            "target_surface": "Chrome-based agent",
            "target_machine": "desktop",
            "locked_scope": ["http://127.0.0.1:8655/BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet"],
            "prompt": (
                "LOCKED SCOPE (Browser Visual Inspection ONLY — Zero File Edits):\n"
                "1. Inspect #testnet at 390x844 and 1440x900.\n"
                "2. Confirm 1 header, 1 footer, 0 nested scrollbars, and working YAY/NAY controls."
            ),
            "auto_inject_hook": False,
            "auto_clipboard": False,
        }
    ]
})
```

**What Happens Automatically Under the Hood:**
1. `chat_goals.py` issues human-readable names (`Closing Claims Chat in Antigravity prompting Antigravity or Claude Code agent for Closing Claims — Audit carrier supplement macros...`), assigns collision-free `chat_id`s in `C:\local-ai\train-requests\_dash\chat_goals_registry.json`, and snapshots live port health (`:8655`, `:7863`, `:7871`, `:7872`, `:7890`, `:8188`, `:5678`).
2. Appends `seed_prompt` to `C:\local-ai\train-requests\_dash\feedback_chat_inbox.jsonl`.
3. On the very next turn in Antigravity, `agy_hooks__lifecycle_to_studio.py --event PreInvocation` consumes `feedback_chat_inbox.jsonl` (tracking consumed IDs in `feedback_chat_cursor.json`) and returns `{"injectSteps": [{"userMessage": seed_prompt}, {"ephemeralMessage": "[STUDIO HOOK PULSE: ...]"}]}` — injecting the prompt directly into the receiving agent's context!
4. Simultaneously dispatches the packet through **AI PowerToy #18** (`remote_prompt_queue.json`, `PROMPT-FOR-LAPTOP-ANTIGRAVITY.md`, Syncthing, OneDrive, Taildrop, and Windows Clipboard) and logs to `agent_chat_pass_and_debug_ledger.jsonl`.

---

### Method C — Cross-Computer Bi-Directional Peer Agent Prompting (`:7891` + Google Drive `EECH-Peer-Agent-Bus`)

To have an agent on **Desktop (`ALOHA` · `100.113.12.85`)** prompt the local Computer-Use Agent on **Laptop (`LAPTOP-RAIDER` · `100.94.239.19`)** — or Laptop prompt Desktop — use **EECH Peer Mesh (`:7891`)**:

#### 1) CLI One-Liner (Desktop <-> Laptop)
```powershell
python "C:\local-ai\studio_job_queue_and_tools\studio_tools\eech_peer_computer_use_agent.py" --ensure-daemon
python "C:\local-ai\studio_job_queue_and_tools\studio_tools\eech_peer_computer_use_agent.py" --send-prompt --to laptop --title "Sync AHK & Verify EECH" --prompt "Sync and merge Google Drive AutoHotkey and reply with verified status"
```

#### 2) HTTP JSON-RPC (`POST http://127.0.0.1:7891/api/eech-peer/prompt` or `POST http://127.0.0.1:8655/api/eech-peer`)
```json
{
  "action": "prompt",
  "target": "laptop",
  "title": "Laptop AHK & EECH Verification",
  "prompt": "Sync Google Drive AutoHotkey, run EECH selftest, and reply back with active AutoHotkey PID.",
  "deterministic_skill": "eech_selftest_and_status",
  "turn": 1,
  "max_turns": 2,
  "stage_ide": true
}
```

#### 3) Dual-Transport Delivery & Bounded Multi-Turn Ping-Pong
1. **Transport 1 — Instant Tailscale HTTP (`<50ms` when awake):** Pushes `POST http://<peer-tailscale-or-lan-ip>:7891/api/eech-peer/receive` (`100.94.239.19:7891` for Laptop; `100.113.12.85:7891` for Desktop). If HTTP `200` returns immediately, the envelope is moved straight to `completed\`.
2. **Transport 2 — Offline-Safe Google Drive Envelope Bus (3-Second Watcher):** Writes an atomic `.tmp -> .json` file to `%USERPROFILE%\My Drive\Shared-Files-Laptop-Desktop-iPhone\EECH-Peer-Agent-Bus\pending\msg_<YYYYMMDD_HHMMSS>_<id>_<from>_to_<to>.json`. As soon as the peer computer wakes up, its resident windowless `pythonw.exe` daemon (`_bus_watcher_loop`) picks up the envelope within 3 seconds, executes safe Zone-1 deterministic skills (`setup_gdrive_ahk_startup`, `sync_and_merge_ahk`, `eech_selftest_and_status`, `screenshot_ground`, `stage_ide_prompt`), moves the message to `completed\`, and writes `replies\reply_<id>_<role>.json`.
3. **Bounded Agent-to-Agent Replies (`MAX_TURN_CAP = 4`):** If `reply_back_prompt` or `followup_prompt_for_peer` is non-empty and `turn < max_turns`, the receiving peer agent automatically sends `[Turn 2/2 Reply from LAPTOP (LAPTOP-RAIDER)]: ...` back to the originating machine and stops cleanly at `max_turns` so infinite loops are impossible.

---

### Method D — UI Picker & Testnet Feedback Injection (`#testnet` -> `spawn_feedback_chat`)

When Joseph (or a browser QA agent recording Joseph's dictation) enters revision notes in `#tp-note` and clicks **`NAY + Feedback`** on [http://127.0.0.1:8655/BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet](http://127.0.0.1:8655/BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet) or [http://127.0.0.1:7863/approve-models](http://127.0.0.1:7863/approve-models) (or runs CLI):
```powershell
python "C:\local-ai\studio_job_queue_and_tools\studio_tools\agy_hooks__lifecycle_to_studio.py" --spawn-chat --model "Juggernaut-XL-v9" --medium "image" --verdict "improve" --note "Warm daylight contrast and verify 5-digit hands"
```
This writes `C:\local-ai\train-requests\_dash\feedback_chats\fbchat_*.json`, appends to `feedback_chat_inbox.jsonl` (for automatic `PreInvocation` injection into Antigravity), stages a fix branch in `multi_agent_plans.json`, and mints a seeded Red-Pill CTO Oracle link (`http://127.0.0.1:7863/oracle?hand=red&pill=cto&seed=...`).

---

### Method E — Semicolon Hotkeys, Claude-to-Antigravity Rescue & Bitwarden Valet (`My Drive\AutoHotkey\all-shortcuts.ahk`)

| Shortcut / Trigger | What It Injects / Executes |
|---|---|
| `;prom0`..`;prom0000` | Pre-Prompt Model Picker & Sub-Task Decomposer (outputs copy-ready `prom1`). |
| `;prom1`..`;prom1111` | `PromptGenesis` Origination Architect (`C:\local-ai` default root + Turn-1 upfront batch permissions + finish-here ethos). |
| `;prom2`..`;prom2222` | Goals Left, Proactive 1-by-1 Solo Completion & Studio SQLite DB Compaction (`VACUUM` + `WAL TRUNCATE` + `PRAGMA optimize`). |
| `;prom3`..`;prom3333` | Pass Chat Relay (**MAX 2 AGENTS, NEVER 3** — 1 separate fenced prompt per agent + Laptop/Desktop sync). |
| `;prom4`..`;prom4444` | Clean Session Wrap-Up, Vault Changelog, Archive Audit & Final State Block. |
| `Ctrl+Alt+Shift+A` (`prom3ac` / `;toagy`) | **0% Claude Quota Rescue**: Copies selected context in Claude, focuses `Antigravity.exe`, and injects the Direct-to-Antigravity continuation prompt (`$0` Free Pools + Local GPU). |
| `Ctrl+Alt+H` (`;beam`) & `;grab` | Beams current clipboard handoff to `LATEST-HANDOFF.md` across Desktop & Laptop (`;grab` pastes it on the other machine). |
| `Ctrl+Alt+Shift+B` (`;bw5`) · `Ctrl+Alt+V` (`;2fa`) · `;door` | **Bitwarden 5-Tab Claims Login Valet**: Fills & submits credentials across 5 open portal tabs in 3s and posts `{}` to `http://127.0.0.1:7887/api/mark-logged-in` so waiting AI agents resume immediately. |

---

## 4. The 7 Iron Safety & Boundary Firewalls (`ActionGuard`)

Every EECH endpoint (`:7863`, `:8655`, `:7891`, `:7890`) and Python entry point runs `check_safety_gate()` BEFORE any action executes:

1. **Zero Secrets or Credential Typing/Pasting (`Hard Law #1`):** Any `type`, `paste`, `ctrl+v`, `shift+insert`, or `peer_prompt` containing passwords, `sk-...` / `ghp_...` / `AIza...` API keys, SSNs, seed phrases, or card numbers is immediately `REFUSED` (including live inspection of the Windows Clipboard before `ctrl+v`).
2. **Zero Bank, Crypto, or Payment UI Interaction (`Hard Law #2`):** Any click, key, or prompt targeting bank logins, wire transfers, wallets, Stripe payouts, or CVV fields is `REFUSED`.
3. **Before & After Visual Evidence (`Hard Law #3`):** Desktop mutations capture sub-200ms PNG evidence (`before_evidence` / `evidence`) and compute `visual_diff_pct` in `C:\local-ai\train-requests\_dash\harness_journal.jsonl`.
4. **Never Delete Files (`Hard Law #4`):** `Remove-Item`, `rm`, `del`, `format`, `shift+delete`, and split-payload delete combos are blocked at both `PreToolUse` (`agy_hooks`) and EECH `check_safety_gate()`. Always archive superseded files to `<root>\_archive\<YYYY-MM-DD>\` and log both ends in `_FOLDER-LOG.txt`.
5. **Zone 0 (`02 Sacral`, `_Private`, `Shadow Work`) & Dedicated Taxes (`[Taxes]` / `t01-dedicated-taxes`) Air-Gap:** Strictly refused to non-isolated business seats and cloud models; Zone 0 stays 100% on local Dual-GPU Ollama (`qwen3:32b`, `qwen2.5-coder:14b`, `hermes3:8b`).
6. **Cross-Business Boundary Firewall & Prepare-Only Gate (`STAGE_ONLY`):** `ClosingClaims` and `PrepRestore` never mix; outward social posts, third-party emails, and spend actions stop 1 click short in `C:\local-ai\train-requests\_staged\` or `#testnet` for Joseph's explicit click.
7. **Human Focus & Physical Mouse Sovereignty:**
   - Moving the physical mouse `> 50 px` during a `combo` immediately aborts with `YIELDED_TO_HUMAN`.
   - Active typing (`idle < 15s–60s`) engages `rig_power_cockpit_and_typing_shield.py` (`_pause_gen`) so RTX 4090 `dwm.exe` (`3440x1440`) and Electron hooks never stutter.
   - **Emergency Instant Kill Switch:** Creating empty file `C:\local-ai\train-requests\_dash\HALT_COMPUTER_USE` halts all EECH motor actions across the rig in `0 ms` (`HALTED`).

---

## 5. Pre-Flight Verification Suite (Run Anytime to Prove 100% Green)

```powershell
python "C:\local-ai\studio_job_queue_and_tools\studio_tools\chat_goals.py" --selftest
python "C:\local-ai\studio_job_queue_and_tools\studio_tools\evolveearth_coworker_harness.py" --selftest
python "C:\local-ai\studio_job_queue_and_tools\studio_tools\eech_peer_computer_use_agent.py" --selftest
python "C:\local-ai\studio_job_queue_and_tools\studio_tools\agy_hooks__lifecycle_to_studio.py" --selftest
python "C:\local-ai\tools-for-ai-agents\18-cross-machine-ai-prompt-dispatcher\cross_machine_prompt_bridge.py" --selftest
```

---

## 6. Copy-Ready Zero-Loss Handoff Prompts (`PASS CHAT 1x` — Max 2 Agents, Never 3)

### Prompt 1 — Local Code, Scripts & EECH Peer Mesh Agent (`Antigravity` or `Claude Code`)

```text
agent_name: EECH Master Handoff in Antigravity prompting Antigravity or Claude Code agent for Local EECH Harness, Scripts, and Desktop-Laptop Peer Mesh Execution
source_chat: EECH Master Handoff in Antigravity
target_agent: Antigravity or Claude Code agent
business: Evolve Earth Studio
goal: Execute local code, studio_tools scripts, SQLite/n8n/ComfyUI backend tasks, and Desktop-to-Laptop EECH peer prompts via :7863/api/harness and :7891

READ FIRST (VERIFIED ON DISK):
1. C:\local-ai\CLAUDE.md
2. C:\local-ai\vault\EECH-MASTER-README-AND-AGENT-INJECTION-HANDOFF.md
3. C:\local-ai\studio_job_queue_and_tools\studio_tools\chat_goals.py
4. C:\local-ai\studio_job_queue_and_tools\studio_tools\evolveearth_coworker_harness.py
5. C:\local-ai\studio_job_queue_and_tools\studio_tools\eech_peer_computer_use_agent.py

HOW TO PROMPT OTHER AGENTS & INJECT INTO EECH:
- Local EECH RPC: POST http://127.0.0.1:7863/api/harness (or import evolveearth_coworker_harness as eech; eech.dispatch({...})).
- Zero-Copy-Paste Handoff (Max 2 Agents, NEVER 3): eech.dispatch({"verb": "pass_chat", "agents": [...]}) -> auto-injects into feedback_chat_inbox.jsonl (Antigravity PreInvocation hook), PowerToy #18 (:7890), and agent_chat_pass_and_debug_ledger.jsonl.
- Cross-Computer Desktop <-> Laptop Peer Agent (:7891 + Google Drive Bus): eech.dispatch({"verb": "peer_prompt", "target": "laptop", "prompt": "...", "max_turns": 2}) or POST http://127.0.0.1:7891/api/eech-peer/prompt.
- Mandatory Plain-English Agent Naming Law: Always use '<Source Role in Surface> calling / prompting <Target Agent> for <Plain-English Goal>' via chat_goals.build_human_agent_name() (0 generic 'Agent 1'/'Agent 2', 0 cartoon callsigns).

LOCKED SCOPE & GUARDRAILS:
- Own all local Python/PowerShell/HTML/Worker code edits, --selftest suites, and headless HTTP checks.
- Do NOT call the Chrome browser extension or hijack mouse/keyboard focus on Joseph's host screen; route any isolated Linux GUI work via "vm": "agent-desk-1" (:6081) or hand off visual browser QA to the Chrome-based agent.
- Back up before editing (C:\local-ai\vault\_BACKUPS\), archive superseded files (_archive\<YYYY-MM-DD>\ + _FOLDER-LOG.txt), never delete, keep Prepare-Only click gates, and log every change to C:\local-ai\vault\_AI-CHANGELOG.md + Google Sheet 1OA4th6DPpNasxkOkq5T03yWAFefFQOsBWn9hsDY1Bco.

MY ACTIVE CHECKLIST:
[ ] Review staged items on http://127.0.0.1:8655/BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet and vote YAY, NAY + Feedback (#tp-note), or NAY · Away
```

### Prompt 2 — Browser Portals & Visual Testnet QA Agent (`Chrome-Based Agent` — Only When Browser Needed)

```text
agent_name: EECH Master Handoff in Antigravity prompting Chrome-based agent for Authenticated Portals and Visual Testnet Quality Check
source_chat: EECH Master Handoff in Antigravity
target_agent: Chrome-based agent
business: Master Toolset Picker
goal: Inspect live visual UI on http://127.0.0.1:7863/harness, http://127.0.0.1:8655/BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet, and https://hibalove.com/testnet/approvals, and inject revision notes back to the code agent

HOW TO INJECT FINDINGS BACK INTO EECH & CODE AGENTS:
1. Visual Harness Console: http://127.0.0.1:7863/harness (and http://127.0.0.1:7891/llms.txt for quick verb lookup).
2. Testnet Feedback -> Automatic Code-Agent Injection: Enter any UI/layout/copy fix in #tp-note on http://127.0.0.1:8655/BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet and click 'NAY + Feedback' — shell_server / agy_hooks writes feedback_chat_inbox.jsonl so the Antigravity code agent receives it automatically on its next PreInvocation turn.
3. Bitwarden Login Valet (:7887): Never type or paste credentials. Ask Joseph to press Ctrl+Alt+Shift+B (;bw5) or Ctrl+Alt+B (;bw1) + ;2fa / ;door, which posts to http://127.0.0.1:7887/api/mark-logged-in when unlocked.

LOCKED SCOPE & GUARDRAILS:
- Browser visual inspection (`390x844` mobile + `1440x900` desktop zero-scroll, 1 header, 1 footer, 0 nested scrollbars) and Prepare-Only portal staging ONLY.
- Zero local file edits, zero git/wrangler CLI commands, zero live form submissions, zero external sends/purchases without Joseph's explicit click.

MY ACTIVE CHECKLIST:
[ ] Press ;bw5 (Ctrl+Alt+Shift+B) if any authenticated portal tab needs login
[ ] Click YAY · Approve or NAY + Feedback on http://127.0.0.1:8655/BUSINESS-GENERATOR-TOOLSET-PICKER.html#testnet
```

## 7. Moving a chat with a goal - the goal wins (2026-11-19, claude-opus-5-5)

- `move_chat_to_free_claude_code_with_eech.py --goal "..."` now treats the goal as the ONLY job.
  Context files written by other chats (`vault\_handoffs\LIVE-CHAT-CONTEXT.md`, `CLAUDE-INBOX-CONTEXT.md`) are
  kept only if written in the last 2 hours, and are labeled "Background only".
- Why: a 7 hour old context from another chat said "your only job in this window" and sat under a new goal.
- Two free windows can run at once (`--force`). Each reads `vault\_handoffs\FREE-CLAUDE-CODE-START.md` once at start;
  older start files are archived in `vault\_handoffs\_archive\<date>\`.
- Free windows run in default permission mode: Joseph approves each edit or command in that window.

### For future agents (there is no separate AGENTS.md - this README is the agent guide)
1. Check health first: `python move_chat_to_free_claude_code_with_eech.py --status`
2. Prove the tunnel: `python eech_tunnel__free_claude_code_to_harness_mcp.py --selftest` (expect 16 tools, 18 PowerToys).
3. Move work with a written goal: `--to fcc --goal "<plain steps, guardrails>"`. Never move a job without a goal.
4. Never put passwords in a goal. Tell the free model which files it must not open (config.php, db.php, .env).
