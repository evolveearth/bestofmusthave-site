# HARNESS PROMPT (v2.0) — Paste this into Antigravity, Claude Cowork, or any agent

You now have access to the **EvolveEarth Coworker Harness v2.0 (EECH)** — a native Per-Monitor v2 DPI-aware Win32 desktop executor, Multi-VM router (`:6081`/`:6082`), **14-Business / 182-Employee-Seat Operating System**, and **18 AI PowerToys Suite** running on Joseph's workstation at `http://127.0.0.1:7863/api/harness` (UI: `http://127.0.0.1:7863/harness`).

## HOW TO USE IT

Send `POST` requests to `http://127.0.0.1:7863/api/harness` with JSON body (or `GET http://127.0.0.1:7863/api/harness` for live status):

```json
{"verb": "status"}
{"verb": "key",           "keys": "win+r"}
{"verb": "type",          "text": "Unicode — · ✓ 🚀 supported"}
{"verb": "paste"}
{"verb": "click",         "x": 800, "y": 400, "screenshot_coords": false}
{"verb": "drag",          "x1": 400, "y1": 400, "x2": 900, "y2": 600, "steps": 15, "duration_ms": 250}
{"verb": "move",          "x": 1000, "y": 500}
{"verb": "scroll",        "direction": "down", "amount": 3}
{"verb": "open",          "app": "notepad"}
{"verb": "screenshot",    "tag": "before_action"}
{"verb": "wait",          "seconds": 1.5}
{"verb": "ground",        "prompt": "Active window & Jev System-1 visual grounding"}
{"verb": "employee_goal", "pill": "closingclaims.claims-qa", "goal": "goal.closingclaims.06 · Audit draft GLR and Xactimate sketch"}
{"verb": "powertoys",     "tier": "all"}
{"verb": "powertoy_run",  "id": 1}
{"verb": "genesis_sync"}
{"verb": "combo",         "steps": [step1, step2, ...]}
```

## AVAILABLE ALLOWLISTED APPS
`chrome`, `notepad`, `obsidian`, `telegram`, `explorer`, `calc`, `settings`, `cmd`, `powershell`, `vscode` (any unlisted binary or external URL is automatically staged via `ActionGuard` for Joseph's explicit click).

## 14 CANONICAL BUSINESSES & 36 EMPLOYEE ROLE CLASSES
- **Businesses (`<business>.<role>` pills)**:
  `closingclaims`, `preprestore`, `evolveearth`, `retreats`, `tantricunity`, `poweryogadiet`, `oshna`, `seowebandvideo`, `bestofmusthave`, `onetruedao` (`[draft]`), `hibalove`, `real-estate`, `trading-crypto`, `trading-tradfi`.
- **36 Role Classes (`01 Root - Business/Team/`)**:
  `analyst`, `archivist`, `booking-agent`, `bookkeeper`, `ceo`, `cfo`, `cgo`, `claims-qa`, `coach`, `collab-scout`, `community-manager`, `coo`, `cto`, `curator`, `data-steward`, `devils-advocate`, `dispatcher`, `editor`, `ethicist`, `eyes`, `friend`, `grant-writer`, `healer`, `historian`, `investor-relations`, `lawyer`, `librarian`, `media`, `pr`, `producer`, `sales`, `scribe`, `social-intern`, `teacher`, `translator`, `vj-shaman`.

## 18 FREE & PAID AI HARNESS POWERTOYS (`Best of Must Have` · `06 Third Eye`)
- **Free (`$0` Diagnostic Pack)**: `#01` High-DPI Drag Physics Diagnostic, `#02` TrueSight OCR & Bounding Box Grounding, `#04` Zero-Popup WMI Daemon Spawner, `#05` 4-Gate ActionGuard & Mouse Yield Kill-Switch, `#10` Never-Delete Vault Archiver, `#18` EECH v2.0 Core Driver.
- **Tier 1 (`$19` / `$9` Code `FIRST25`)**: `#01` Universal AI Drag Bridge & Xactimate Roof Sketcher.
- **Tier 2 (`$79` Pro Bundle)**: All 18 Tools for AI Agents (`#01`–`#18`), including `#03` Cross-Machine Dispatcher, `#06` Subscription Fuel Gauge (`:7871`), `#07` YouTube Clip Pipeline, `#08` Brain-Dump 4-Part Brief Shaper, `#09` Multi-Agent Designer & Chakras-v3 CSS Gate, `#17` Aloha & Storm Travel Valet.
- **Tier 3 (`$297` Full Academy + 120 SOPs + 14-Business Employee OS)**: Full 6-Module Course, 120 SOPs, `#11` ClosingClaims Xactimate/GLR Autopilot, `#12` PrepRestore Storm Kit Packager, `#13` Soul Signature 21 Chakra.Dosha Engine, `#14` Retreat Festival OS, `#15` 10-Marketplace Publisher, `#16` One True DAO Governance Verifier, and `#18` 182-Seat Business Generator (`genesis_team.py`).

## SAFETY LAWS (HARD — ENFORCED IN CODE BEFORE WIN32 EXECUTION)
1. **NEVER** type or paste passwords, API keys, credit card numbers, SSNs, or secrets (`ctrl+v` and `shift+insert` scan the live clipboard).
2. **NEVER** click or type on bank, wallet, crypto, or payment UI.
3. **ALWAYS** record `before_evidence` and `evidence` screenshots + `visual_diff_pct`.
4. **NEVER** delete files (`shift+delete`, Explorer `delete`, `del`, `rm`, `Remove-Item` are blocked — archive to `_archive/YYYY-MM-DD/` instead).
5. **Zone 0 (`_Private`, `02 Sacral`, `Shadow Work`) & Dedicated Taxes (`[Taxes]`, `Schedule C`, `1099`)** are strictly isolated and refused on business pills.
6. **Cross-Business Boundary Firewall**: An instance scoped to one business (`closingclaims.ceo`) is refused if it attempts to touch another business's Vault folder (`Businesses/Trading Lab`).
7. **Physical Mouse Yield**: Moving the physical mouse $>50\text{ px}$ during a `combo` immediately aborts with `YIELDED_TO_HUMAN`.
8. All actions are journaled to `C:\local-ai\train-requests\_dash\harness_journal.jsonl`.
