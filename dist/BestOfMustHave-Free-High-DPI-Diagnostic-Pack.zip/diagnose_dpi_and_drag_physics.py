#!/usr/bin/env python3
"""
Best of Must Have — Free High-DPI AI Computer Use & Drag Threshold Diagnostic
Tests your Windows 11 monitors, DPI scaling factor, and OS drag thresholds (SM_CXDRAG / SM_CYDRAG)
to show why raw AI Computer Use agents miss coordinates or fail click-and-drag.
"""

import ctypes
import json
import sys


def run_diagnostic() -> dict:
    user32 = ctypes.windll.user32
    shcore = getattr(ctypes.windll, "shcore", None)

    # Read default (unaware) virtual screen vs DPI-aware physical screen
    virtual_w = user32.GetSystemMetrics(0)  # SM_CXSCREEN
    virtual_h = user32.GetSystemMetrics(1)  # SM_CYSCREEN
    drag_thresh_x = user32.GetSystemMetrics(68)  # SM_CXDRAG
    drag_thresh_y = user32.GetSystemMetrics(69)  # SM_CYDRAG
    virtual_desktop_w = user32.GetSystemMetrics(78)  # SM_CXVIRTUALSCREEN
    virtual_desktop_h = user32.GetSystemMetrics(79)  # SM_CYVIRTUALSCREEN

    # Enable Per-Monitor DPI Awareness v2 (-4)
    try:
        user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass

    physical_w = user32.GetSystemMetrics(0)
    physical_h = user32.GetSystemMetrics(1)
    physical_desktop_w = user32.GetSystemMetrics(78)
    physical_desktop_h = user32.GetSystemMetrics(79)

    scale_pct = round((physical_w / virtual_w) * 100) if virtual_w else 100

    report = {
        "ok": True,
        "diagnostic": "Best of Must Have — High-DPI AI Computer Use Diagnostic",
        "primary_monitor": {
            "unaware_virtual_resolution": f"{virtual_w}x{virtual_h}",
            "physical_dpi_v2_resolution": f"{physical_w}x{physical_h}",
            "detected_windows_scaling_percent": f"{scale_pct}%",
        },
        "multi_monitor_desktop": {
            "virtual_span": f"{virtual_desktop_w}x{virtual_desktop_h}",
            "physical_span": f"{physical_desktop_w}x{physical_desktop_h}",
        },
        "os_drag_threshold_pixels": {
            "SM_CXDRAG": drag_thresh_x,
            "SM_CYDRAG": drag_thresh_y,
            "why_ai_fails": (
                f"Windows ignores any drag until the cursor moves >{drag_thresh_x}px horizontally or "
                f">{drag_thresh_y}px vertically while holding the button down. Instant AI coordinate jumps skip "
                "intermediate WM_MOUSEMOVE events and fail to wake up target folders."
            ),
        },
        "solution": (
            "Upgrade to the Universal AI Drag Bridge ($19 — or $9 for the first 25 buyers with code FIRST25) "
            "to get Per-Monitor DPI v2 locking, 3/6/10px threshold micro-nudges, 30-step glide, 2px folder hover "
            "wiggle, 5 universal drag modes, and the Claude/Cursor MCP Server."
        ),
    }
    return report


if __name__ == "__main__":
    print(json.dumps(run_diagnostic(), indent=2))
    sys.exit(0)
